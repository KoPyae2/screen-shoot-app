mod capture;
mod clipboard;
mod history;
mod imaging;
mod models;
mod overlay;
mod saving;

use std::sync::Mutex;

use tauri::{Emitter, Manager};
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut, ShortcutState};

use overlay::RegionStore;

/// Last foreground window HWND, recorded by the shortcut handler before focusing Snapture.
pub(crate) static ACTIVE_WINDOW_TARGET: Mutex<Option<u32>> = Mutex::new(None);

/// The three quick-capture global shortcuts.
fn shortcuts() -> (Shortcut, Shortcut, Shortcut) {
    let mods = Modifiers::CONTROL | Modifiers::SHIFT;
    (
        Shortcut::new(Some(mods), Code::Digit1), // region
        Shortcut::new(Some(mods), Code::Digit2), // full screen
        Shortcut::new(Some(mods), Code::Digit3), // active window
    )
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(move |app, shortcut, event| {
                    if event.state() != ShortcutState::Pressed {
                        return;
                    }
                    let (region_key, full_key, win) = shortcuts();
                    let kind = if shortcut == &region_key {
                        "region"
                    } else if shortcut == &full_key {
                        "fullscreen"
                    } else if shortcut == &win {
                        "window"
                    } else {
                        return;
                    };
                    // Record foreground window BEFORE focusing Snapture
                    if kind == "window" {
                        let _ = ACTIVE_WINDOW_TARGET.lock().map(|mut t| {
                            *t = crate::capture::foreground_window_id()
                        });
                    }
                    if let Some(w) = app.get_webview_window("main") {
                        // Don't yank focus back to main if a region overlay is
                        // currently visible (mid-selection). Otherwise main would
                        // pop up underneath the overlay.
                        let overlay_active = app
                            .webview_windows()
                            .iter()
                            .any(|(l, win)| {
                                l.starts_with("overlay-")
                                    && win.is_visible().unwrap_or(false)
                            });
                        if !overlay_active {
                            let _ = w.show();
                            let _ = w.set_focus();
                        }
                        // Emit only to main, not to overlay windows (they don't
                        // listen for this and don't need the broadcast).
                        let _ = w.emit("capture-request", kind);
                    }
                })
                .build(),
        )
        .manage(RegionStore::default())
        .setup(|app| {
            let handle = app.handle().clone();
            imaging::clean_sessions(&handle);

            let (region_key, full_key, win_key) = shortcuts();
            let gs = handle.global_shortcut();
            if let Err(e) = gs.register(region_key) {
                eprintln!("shortcut register region failed: {e}");
            }
            if let Err(e) = gs.register(full_key) {
                eprintln!("shortcut register fullscreen failed: {e}");
            }
            if let Err(e) = gs.register(win_key) {
                eprintln!("shortcut register window failed: {e}");
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            capture::list_monitors,
            capture::list_windows,
            capture::capture_monitor,
            capture::capture_all_monitors,
            capture::capture_window,
            capture::capture_active_window,
            overlay::begin_region_capture,
            overlay::region_payload,
            overlay::region_image_bytes,
            overlay::finish_region_capture,
            overlay::cancel_region_capture,
            clipboard::copy_image_to_clipboard,
            clipboard::copy_bytes_to_clipboard,
            saving::save_image_bytes,
            imaging::read_image_data_url,
            history::history_list,
            history::history_delete,
            history::history_clear,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
